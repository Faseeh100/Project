

 <?php $__env->startSection('content'); ?>
 
 <div class="pagetitle">
      <h1>Active Job</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item">Job</li>
          <li class="breadcrumb-item active">All Job</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Datatables</h5>
             
              <!-- Table with stripped rows -->
              <table class="table datatable">
                <thead>
                  <tr>
                    <th>
                      Id
                    </th>
                    <th>Title</th>
                    <th>Location</th>
                    <th>Job Type</th>
                    <th>Salary</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(sizeof($jobs)>0): ?>
                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($job->id); ?> </td>
                      <td><a href="<?php echo e(route('listjobview',$job->id)); ?>"><?php echo e($job->title); ?></a></td>
                      <td><?php echo e($job->location); ?></td>
                      <td><?php echo e($job->job_type); ?></td>
                      <td><?php echo e($job->salary); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  <p>No record Found</p>
                  <?php endif; ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>



    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layoutemployer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bitlogics\Online Job Portal\online_job_portal\resources\views/employer/pages/avaliblejob.blade.php ENDPATH**/ ?>