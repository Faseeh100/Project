<footer class="site-footer">

<a href="#top" class="smoothscroll scroll-top">
  <span class="icon-keyboard_arrow_up"></span>
</a>

<div class="container text-center text-white">
      Copyright &copy;<script>document.write(new Date().getFullYear());</script>
</div>
</footer>
<?php /**PATH C:\Users\muham\OneDrive\Desktop\onlinejobportal\resources\views/components/footer.blade.php ENDPATH**/ ?>