<?php $__env->startSection('content'); ?>


    <div class="pagetitle">
        <h1>Publish Job</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item">Job</li>
                <li class="breadcrumb-item active">Publish Job</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Job Details</h5>

                        <!-- Floating Labels Form -->
                        <form method="POST" action="<?php echo e(route('editjob', $data->id)); ?>" class="row g-3">
                            <?php echo csrf_field(); ?>

                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control" value="<?php echo e($data->title); ?>" name="title" id="Title" placeholder="Title">
                                    <label for="Title">Title</label>
                                </div>
                                <?php $__errorArgs = ["title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control" value="<?php echo e($data->location); ?>" name="location" id="floatingName" placeholder="Your Name">
                                    <label for="floatingName">Location</label>
                                </div>
                                <?php $__errorArgs = ["location"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea class="form-control"  name="description" placeholder="Description" id="floatingTextarea" style="height: 100px;"><?php echo e($data->description); ?></textarea>
                                    <label for="Description">Description</label>
                                </div>
                                <?php $__errorArgs = ["discription"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea class="form-control"  name="requirements" placeholder="Requirements" id="Requirements" style="height: 100px;"><?php echo e($data->requirements); ?></textarea>
                                    <label for="Requirements">Requirements</label>
                                </div>
                                <?php $__errorArgs = ["requirements"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>


                            <div class="col-md-4">
                                <div class="form-floating mb-3">
                                    <select class="form-select" name="job_type" id="job_type" aria-label="State">
                                        <option value="Full Time" selected>Full Time</option>
                                        <option value="Part Time">Part Time</option>
                                        <option value="Online">Online </option>
                                    </select>
                                    <label for="floatingSelect">Job Type</label>
                                </div>
                                <?php $__errorArgs = ["job_type"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <div class="form-floating">
                                    <input type="text" class="form-control" value="<?php echo e($data->salary); ?>" name="salary" id="Salary" placeholder="Salary">
                                    <label for="Salary">Salary</label>
                                </div>
                                <?php $__errorArgs = ["salary"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <div class="form-floating">
                                    <input type="text" class="form-control" value="<?php echo e($data->expierence); ?>" name="expierence" id="expierence" placeholder="Experience">
                                    <label for="expierence">Experience</label>
                                </div>
                                <?php $__errorArgs = ["expierence"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="text-end">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form><!-- End floating Labels Form -->

                    </div>
                </div>

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layoutemployer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muham\OneDrive\Desktop\online-job-portal\resources\views/employer/pages/editjob.blade.php ENDPATH**/ ?>