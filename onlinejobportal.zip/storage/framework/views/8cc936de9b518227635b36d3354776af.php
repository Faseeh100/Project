

 <?php $__env->startSection('content'); ?>

    <div class="pagetitle">
      <h1>Application</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item">Tables</li>
          <li class="breadcrumb-item active">Data</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Application </h5>

              <!-- Table with stripped rows -->
              <table class="table datatable">
                <thead>
                  <tr>
                    <th>
                      Title
                    </th>
                    <th>Name</th>
                    <th>resume</th>

                    <th>cover_latter</th>
                  </tr>
                </thead>
                <tbody>
                <?php echo e($applications); ?>

                <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><a href="<?php echo e(route('listjobview',$application->job_listing_id)); ?>"><?php echo e($application->title); ?></a></td>
                    <td><?php echo e($application->first_name); ?> <?php echo e($application->last_name); ?></td>
                    <td><a download class="btn btn-sm btn-primary" href="<?php echo e(asset('storage/'.$application->resume)); ?>">Download</td>
                    <td><a download class="btn btn-sm btn-primary" href="<?php echo e(asset('storage/'.$application->cover_latter)); ?>">Download</td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layoutemployer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muham\OneDrive\Desktop\online-job-portal\resources\views/employer/pages/application.blade.php ENDPATH**/ ?>