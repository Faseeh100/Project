<aside id="sidebar" class="sidebar">

<ul class="sidebar-nav" id="sidebar-nav">

  <li class="nav-item">
    <a class="nav-link " href="<?php echo e(route('dashboard')); ?>">
      <i class="bi bi-grid"></i>
      <span>Dashboard</span>
    </a>
  </li><!-- End Dashboard Nav -->

  <li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
      <i class="bi bi-menu-button-wide"></i><span>Jobs</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
      <li>
        <a href="<?php echo e(route('addjobview')); ?>">
          <i class="bi bi-circle"></i><span>Publish Jobs</span>
        </a>
      </li>
      <li>
        <a href="<?php echo e(route('avaliblejobview')); ?>">
          <i class="bi bi-circle"></i><span>Active Jobs</span>
        </a>
      </li>
      <li>
        <a href="<?php echo e(route('alljobview')); ?>">
          <i class="bi bi-circle"></i><span>All Jobs</span>
        </a>
      </li>

    </ul>
  </li>


    <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('applicationview')); ?>">
            <i class="bx bxs-detail"></i>
            <span>Applications</span>
        </a>
    </li>

  <li class="nav-item">
    <a class="nav-link collapsed" href="<?php echo e(route('profileview')); ?>">
      <i class="bi bi-person"></i>
      <span>Profile</span>
    </a>
  </li><!-- End Profile Page Nav -->


</ul>

</aside><!-- End Sidebar-->
<?php /**PATH C:\Users\muham\OneDrive\Desktop\online-job-portal\resources\views/employer/components/employersidebar.blade.php ENDPATH**/ ?>