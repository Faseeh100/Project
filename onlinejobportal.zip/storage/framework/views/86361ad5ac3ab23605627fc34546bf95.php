<!doctype html>
<html class="no-js" lang="zxx">
    <head>
        
		  <?php echo $__env->make('partials.headlinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent("headlinks"); ?>
        
        <title><?php echo $__env->yieldContent("pagetitle"); ?></title>
   </head>


   <body>
    <!-- Preloader Start -->
    <div id="overlayer"></div>
  <div class="loader">
    <div class="spinner-border text-primary" role="status">
      <span class="sr-only">Loading...</span>
    </div>
  </div>
    <?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
     <?php echo $__env->yieldContent('content'); ?>

     <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
    <!-- JS here -->
	
    <?php echo $__env->make('partials.footerlinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent("footerlinks"); ?>
    
</html><?php /**PATH D:\Bitlogics\Online Job Portal\online_job_portal\resources\views/layout/layout.blade.php ENDPATH**/ ?>