 <!-- SCRIPTS -->
 <script    src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/stickyfill.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.fancybox.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.easing.1.3.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.animateNumber.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/quill.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
<?php /**PATH C:\Users\muham\OneDrive\Desktop\onlinejobportal\resources\views/partials/footerlinks.blade.php ENDPATH**/ ?>