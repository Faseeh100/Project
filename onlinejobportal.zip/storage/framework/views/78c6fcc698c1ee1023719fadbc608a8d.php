

 <?php $__env->startSection('content'); ?>

<section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(asset('images/hero_1.jpg')); ?>);" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Post A Job</h1>
            <div class="custom-breadcrumbs">
              <a href="<?php echo e(route('home')); ?>">Home</a> <span class="mx-2 slash">/</span>
              <a href="#">Job</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Post a Job</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    
    <section class="site-section">
      <div class="container">

        <div class="row align-items-center mb-5">
          <div class="col-lg-8 mb-4 mb-lg-0">
            <div class="d-flex align-items-center">
              <div>
                <h2>Post A Job</h2>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="row">
            
              <div class="col-6">
                <a href="#" class="btn btn-block btn-primary btn-md">Submit</a>
              </div>
            </div>
          </div>
        </div>
        <div class="row mb-5">
          <div class="col-lg-12">
            <form class="p-4 p-md-5 border rounded" enctype="multipart/form-data" action="<?php echo e(route('submit')); ?>" method="post">
            <?php echo csrf_field(); ?>
              <h3 class="text-black mb-5 border-bottom pb-2">Job Details</h3>
              
             <input type="hidden" name="job_listing_id" value="<?php echo e($id); ?>">

              <div class="form-group">
                <label for="fist name">First Name</label>
                <input type="text" class="form-control" name="first_name"  value="<?php echo e(old('first_name')); ?>" id="first_name" placeholder="Fist Name">
                <?php $__errorArgs = ["first_name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group">
                <label for="Last Name">Last Name</label>
                <input type="text" class="form-control" name="last_name"  value="<?php echo e(old('last_name')); ?>" id="last_name" placeholder="Last Name">
                <?php $__errorArgs = ["last_name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group">
                <label for="Address">Address</label>
                <input type="text" class="form-control" name="address"  value="<?php echo e(old('address')); ?>" id="address" placeholder="Enter Your Address">
                <?php $__errorArgs = ["address"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group">
                <label for="Phone">Phone</label>
                <input type="tel" class="form-control" name="phone"  value="<?php echo e(old('phone')); ?>" id="phone" placeholder="Enter Number">
                <?php $__errorArgs = ["phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group ">
                <label for="Resume">Resume</label>
                <input type="file" class="form-control border-0"  name="resume" id="resume" >
                <?php $__errorArgs = ["resume"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group ">
                <label for="cover_letter">Cover Letter</label>
                <input type="file" class="form-control border-0" name="cover_latter" id="cover_latter" >
                <?php $__errorArgs = ["cover_latter"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="col-6">
                <button class="btn btn-block btn-primary btn-md">Submit</button>
              </div>


            
              
            </form>
          </div>

         
        </div>
        
      </div>
    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bitlogics\Online Job Portal\online_job_portal\resources\views/pages/postjob.blade.php ENDPATH**/ ?>