Laravel- Php Framework -> secure and powerfull backend
Bootstap 5.3 -> html css js
jQuery -> js library


Laravel -> Model View Controller  

Model -> app/Models
View -> resources/views
Controller -> app/Http/Controllers
~~Routes -> routes/web.php~~

flow of app

Reuest /login
Routes /login -> Controller, fun

1. View                         2. Model View
display                         fetch data -> database
                                view -> display
