<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="Free-Template.co" />
    <link rel="shortcut icon" href="<?php echo e(asset('ftco-32x32.png')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/custom-bs.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.fancybox.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/icomoon/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/line-icons/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/quill.snow.css')); ?>">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">    
<?php /**PATH C:\Users\muham\OneDrive\Desktop\onlinejobportal\resources\views/partials/headlinks.blade.php ENDPATH**/ ?>